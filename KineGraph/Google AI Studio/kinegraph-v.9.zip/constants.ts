import { MovementType, Mobile } from "./types";

export const COLORS = ['#EF4444', '#3B82F6', '#10B981', '#F97316', '#D946EF', '#8B5CF6']; // Red, Blue, Green, Orange, Fuchsia, Violet
export const G = -9.8;
